/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 * 
 *  Student: Ronnel Ynot
    Student ID: x21751299

    Reference: https://www.w3schools.com/
 */

var upcomingMovies = {
    "upcomingFilms": [
        {
            "name": "The Little Mermaid",
            "releaseDate": "May 26, 2023",
            "description": "Ursula, the sea witch, makes a devious deal with Princess Ariel allowing her to meet Eric, the human prince she loves."
        },

        {
            "name": "Avatar The Way of Water",
            "releaseDate": "December 16, 2022",
            "description": "When an ancient threat resurfaces, Jake must fight a difficult war against the humans."
        },

        {
            "name": "Spiderman Across The Univerese",
            "releaseDate": "June 2, 2023",
            "description": "Miles Morales embarks on an epic adventure that will transport Brooklyn's neighbourhood spiderman"
        },

        {
            "name": "Oppenheimer",
            "releaseDate": "July 21, 2023 ",
            "description": "Physicist J Robert Oppenheimer's part in developing the atomic bomb"
        }
    ]
};

var nameMovie = document.getElementById("name");
nameMovie.innerHTML = upcomingMovies.upcomingFilms[0].name;
var movieDate = document.getElementById("releasedate");
movieDate.innerHTML = upcomingMovies.upcomingFilms[0].releaseDate;
var descriptionMovie = document.getElementById("descriptionmovie");
descriptionMovie.innerHTML = upcomingMovies.upcomingFilms[0].description;

var nameMovie2 = document.getElementById("name2");
nameMovie2.innerHTML = upcomingMovies.upcomingFilms[1].name;
var movieDate2 = document.getElementById("releasedate2");
movieDate2.innerHTML = upcomingMovies.upcomingFilms[1].releaseDate;
var descriptionMovie2 = document.getElementById("descriptionmovie2");
descriptionMovie2.innerHTML = upcomingMovies.upcomingFilms[1].description;

var nameMovie3 = document.getElementById("name3");
nameMovie3.innerHTML = upcomingMovies.upcomingFilms[2].name;
var movieDate3 = document.getElementById("releasedate3");
movieDate3.innerHTML = upcomingMovies.upcomingFilms[2].releaseDate;
var descriptionMovie3 = document.getElementById("descriptionmovie3");
descriptionMovie3.innerHTML = upcomingMovies.upcomingFilms[2].description;

var nameMovie4 = document.getElementById("name4");
nameMovie4.innerHTML = upcomingMovies.upcomingFilms[3].name;
var movieDate4 = document.getElementById("releasedate4");
movieDate4.innerHTML = upcomingMovies.upcomingFilms[3].releaseDate;
var descriptionMovie4 = document.getElementById("descriptionmovie4");
descriptionMovie4.innerHTML = upcomingMovies.upcomingFilms[3].description;

// my variables
let mySlideNum = 1;
showPicture(mySlideNum);

// Next and back buttons
function morePicture(n) {
    showPicture(mySlideNum += n);
}

// Pictures/Images control
function currentPicture(n) {
    showPicture(mySlideNum = n);
}

// function for showing Image slide
function showPicture(n) {
    let i;
    let picSlides = document.getElementsByClassName("mypicslides");
    let userClick = document.getElementsByClassName("circle");
    if (n > picSlides.length) {
        mySlideNum = 1;
    }
    if (n < 1) {
        mySlideNum = picSlides.length;
    }
    for (i = 0; i < picSlides.length; i++) {
        picSlides[i].style.display = "none";
    }
    for (i = 0; i < userClick.length; i++) {
        userClick[i].className = userClick[i].className.replace(" active", "");
    }
    picSlides[mySlideNum - 1].style.display = "block";
    userClick[mySlideNum - 1].className += " active";
};

async function getUpcomingMoviesData(url) {
    var addTableData = "<tr><th>Name</th><th>Director</th><th>Genre</th></tr>";
    var takeData = await fetch(url);
    var getData = await takeData.json();

    for (i = 0; i < getData.length; i++) {
        addTableData += "<tr><td>" + getData[i]["name"]+"</td><td>"+
                getData[i]["director"]+"</td><td>"+
                getData[i]["genre"]+"</td></tr>";
        
    }
    document.getElementById("movieTable3").innerHTML = addTableData;
}