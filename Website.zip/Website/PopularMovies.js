/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 * 
 * Student: Ryan Byrne
 * Student ID: x21503956
 * 
 * Reference: https://www.w3schools.com/
 */

var PopularFilms = {
    "popularMovies": [
        {
            "name": "The Batman",
            "releaseDate": "March 4, 2022",
            "description": "Batman is called to intervene when the mayor of Gotham City is murdered."
        },

        {
            "name": "Athena",
            "releaseDate": "September 2, 2022",
            "description": "Athena is a 2022 French epic action drama film directed by Romain Gavras "
        },

        {
            "name": "Prey",
            "releaseDate": "July 21, 2022",
            "description": "A skilled Comanche warrior protects her tribe from a highly evolved alien predator that hunts humans"
        },

        {
            "name": "Top Gun Maverick",
            "releaseDate": "May 27, 2022",
            "description": "After more than 30 years of service as one of the Navy's top aviators"
        }
    ]
};

var nameMovie = document.getElementById("name");
nameMovie.innerHTML = PopularFilms.popularMovies[0].name;
var movieDate = document.getElementById("releasedate");
movieDate.innerHTML = PopularFilms.popularMovies[0].releaseDate;
var descriptionMovie = document.getElementById("descriptionmovie");
descriptionMovie.innerHTML = PopularFilms.popularMovies[0].description;

var nameMovie2 = document.getElementById("name2");
nameMovie2.innerHTML = PopularFilms.popularMovies[1].name;
var movieDate2 = document.getElementById("releasedate2");
movieDate2.innerHTML = PopularFilms.popularMovies[1].releaseDate;
var descriptionMovie2 = document.getElementById("descriptionmovie2");
descriptionMovie2.innerHTML = PopularFilms.popularMovies[1].description;

var nameMovie3 = document.getElementById("name3");
nameMovie3.innerHTML = PopularFilms.popularMovies[2].name;
var movieDate3 = document.getElementById("releasedate3");
movieDate3.innerHTML = PopularFilms.popularMovies[2].releaseDate;
var descriptionMovie3 = document.getElementById("descriptionmovie3");
descriptionMovie3.innerHTML = PopularFilms.popularMovies[2].description;

var nameMovie4 = document.getElementById("name4");
nameMovie4.innerHTML = PopularFilms.popularMovies[3].name;
var movieDate4 = document.getElementById("releasedate4");
movieDate4.innerHTML = PopularFilms.popularMovies[3].releaseDate;
var descriptionMovie4 = document.getElementById("descriptionmovie4");
descriptionMovie4.innerHTML = PopularFilms.popularMovies[3].description;

// my variables
let mySlideNum = 1;
showPicture(mySlideNum);

// Next and back buttons
function morePicture(n) {
    showPicture(mySlideNum += n);
}

// Pictures/Images control
function currentPicture(n) {
    showPicture(mySlideNum = n);
}

// function for showing Image slide
function showPicture(n) {
    let i;
    let picSlides = document.getElementsByClassName("mypicslides");
    let userClick = document.getElementsByClassName("circle");
    if (n > picSlides.length) {
        mySlideNum = 1;
    }
    if (n < 1) {
        mySlideNum = picSlides.length;
    }
    for (i = 0; i < picSlides.length; i++) {
        picSlides[i].style.display = "none";
    }
    for (i = 0; i < userClick.length; i++) {
        userClick[i].className = userClick[i].className.replace(" active", "");
    }
    picSlides[mySlideNum - 1].style.display = "block";
    userClick[mySlideNum - 1].className += " active";
}
;

async function getPopularMoviesData(url) {
    var addTableData = "<tr><th>Name</th><th>Director</th><th>Genre</th><th>Rating</th></tr>";
    var takeData = await fetch(url);
    var getData = await takeData.json();

    for (i = 0; i < getData.length; i++) {
        addTableData += "<tr><td>" + getData[i]["name"]+"</td><td>"+
                getData[i]["director"]+"</td><td>"+
                getData[i]["genre"]+"</td><td>"+
                getData[i]["rating"]+"</td></tr>";
        
    }
    document.getElementById("movieTable2").innerHTML = addTableData;
}