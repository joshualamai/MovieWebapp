/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 * 
 * Student: Ryan Byrne
 * Student ID: x21503956
 * 
 * Reference: https://www.w3schools.com/
 */

// creating variables for JSON
var newMovies = {
    "newRelease": [
        {
            "name": "Black Adam",
            "releaseDate": "October 21, 2022",
            "description": "teth adam was bestowed with the power of the gods and is now free after 5,000 years"
        },

        {
            "name": "The Menu",
            "releaseDate": "November 18, 2022",
            "description": "the film focuses on a young couple who visits an exclusive destination restaurant on a remote island"
        },

        {
            "name": "Superpets",
            "releaseDate": "July 29, 2022",
            "description": "superdog krypto and his friends are on a mission to save a kidnapped superman"
        },

        {
            "name": "Don't Worry Darling",
            "releaseDate": "September 23, 2022",
            "description": "In the 1950s, Alice and Jack live in the idealized community of Victory, an experimental company town"
        }

    ]
};
//main page
var nameMovie = document.getElementById("name");
nameMovie.innerHTML = newMovies.newRelease[0].name;
var movieDate = document.getElementById("releasedate");
movieDate.innerHTML = newMovies.newRelease[0].releaseDate;
var descriptionMovie = document.getElementById("descriptionmovie");
descriptionMovie.innerHTML = newMovies.newRelease[0].description;

var nameMovie2 = document.getElementById("name2");
nameMovie2.innerHTML = newMovies.newRelease[1].name;
var movieDate2 = document.getElementById("releasedate2");
movieDate2.innerHTML = newMovies.newRelease[1].releaseDate;
var descriptionMovie2 = document.getElementById("descriptionmovie2");
descriptionMovie2.innerHTML = newMovies.newRelease[1].description;

var nameMovie3 = document.getElementById("name3");
nameMovie3.innerHTML = newMovies.newRelease[2].name;
var movieDate3 = document.getElementById("releasedate3");
movieDate3.innerHTML = newMovies.newRelease[2].releaseDate;
var descriptionMovie3 = document.getElementById("descriptionmovie3");
descriptionMovie3.innerHTML = newMovies.newRelease[2].description;

var nameMovie4 = document.getElementById("name4");
nameMovie4.innerHTML = newMovies.newRelease[3].name;
var movieDate4 = document.getElementById("releasedate4");
movieDate4.innerHTML = newMovies.newRelease[3].releaseDate;
var descriptionMovie4 = document.getElementById("descriptionmovie4");
descriptionMovie4.innerHTML = newMovies.newRelease[3].description;

// my variables
let mySlideNum = 1;
showPicture(mySlideNum);

// Next and back buttons
function morePicture(n) {
    showPicture(mySlideNum += n);
}

// Pictures/Images control
function currentPicture(n) {
    showPicture(mySlideNum = n);
}

// function for showing Image slide
function showPicture(n) {
    let i;
    let picSlides = document.getElementsByClassName("mypicslides");
    let userClick = document.getElementsByClassName("circle");
    if (n > picSlides.length) {
        mySlideNum = 1;
    }
    if (n < 1) {
        mySlideNum = picSlides.length;
    }
    for (i = 0; i < picSlides.length; i++) {
        picSlides[i].style.display = "none";
    }
    for (i = 0; i < userClick.length; i++) {
        userClick[i].className = userClick[i].className.replace(" active", "");
    }
    picSlides[mySlideNum - 1].style.display = "block";
    userClick[mySlideNum - 1].className += " active";
}
;

async function getNewReleaseData(url) {
    var addTableData = "<tr><th>Name</th><th>Director</th><th>Genre</th><th>Rating</th></tr>";
    var takeData = await fetch(url);
    var getData = await takeData.json();

    for (i = 0; i < getData.length; i++) {
        addTableData += "<tr><td>" + getData[i]["name"]+"</td><td>"+
                getData[i]["director"]+"</td><td>"+
                getData[i]["genre"]+"</td><td>"+
                getData[i]["rating"]+"</td></tr>";
        
    }
    document.getElementById("movieTable").innerHTML = addTableData;
}